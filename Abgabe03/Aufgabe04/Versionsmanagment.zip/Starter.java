public class Starter {

    public static void main(final String[] args) {
        System.out.println("42");
    }

}